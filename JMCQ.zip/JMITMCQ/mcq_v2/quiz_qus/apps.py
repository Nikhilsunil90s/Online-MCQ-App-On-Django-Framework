from django.apps import AppConfig


class QuizQusConfig(AppConfig):
    name = 'quiz_qus'
