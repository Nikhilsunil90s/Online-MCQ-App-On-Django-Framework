from django.shortcuts import render, redirect
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from .forms import ContactForm
# Create your views here.
def contactushere(request):
    return render(request,'contactus/contact.html')
    '''if request.method == "POST":
        form = ContactUsForm(request.POST)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            sender_name = form.cleaned_data['name']
            from_email = form.cleaned_data['from_email']
            message = "{0} has sent you a new message:\n\n{1}".format(sender_name, form.cleaned_data['message'])
            send_mail(subject,message,['pyappmedia@gmail.com'],['pyappmedia@gmail.com'])
            return HttpResponse("Thanks..")
        else:
            form = ContactForm()
            return render(request,'contactus/contact.html',{'form':form})'''
        
    
'''def successes(request):
    return HttpResponse("Your query sent successfuly")'''

                
            
        
        
    
