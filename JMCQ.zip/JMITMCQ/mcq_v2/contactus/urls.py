from django.contrib import admin
from django.urls import path
from django.views.generic import TemplateView
#from contact_form.views import  ContactFormView
from .views import contactushere

urlpatterns = [
    path('',contactushere, name = 'contact'),
    #path('done/',successes, name='done')
    ]
