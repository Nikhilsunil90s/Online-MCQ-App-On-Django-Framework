from django.contrib import admin
from .models import quizze
# Register your models here.

admin.site.register(quizze)
